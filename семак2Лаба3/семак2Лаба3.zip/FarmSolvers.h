#pragma once
#include "SolverEulerMethod.h"
#include "SolverMethodHoina.h"
#include <string>

class FarmSolvers
{
private:
	unsigned int CounterOfSolversEulerMethod, CounterOfSolversMethodHoina;

	//�� ������ ������� ��� ����� ���������� �������� ��� �������
	SolverEulerMethod *ArraySolversEulerMethod = new SolverEulerMethod[3];
	SolverMethodHoina *ArraySolversMethodHoina = new SolverMethodHoina[3];
	
public:
	FarmSolvers()
		:CounterOfSolversEulerMethod(0), CounterOfSolversMethodHoina(0)
	{}
	
	class Errors{};

	void CheckNameRepeat(const std::string Name)const;
	void AddSolverEulerMethod(std::string, unsigned int, unsigned int);
	void AddSolverMethodHoina(std::string Name, unsigned int, unsigned int);
	void DeleteMethod(std::string &Name);
	void SolveProblem(const TaskKoshi& Task)const;
	void ShowResults(const std::string Name)const;
	unsigned int GetSumOfCountersMethods(); //?

	~FarmSolvers() 
	{
		delete[]ArraySolversEulerMethod;
		delete[]ArraySolversMethodHoina;
	}
};
