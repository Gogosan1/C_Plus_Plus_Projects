#pragma once
class ArraySolvers
{
private:

};

